#include <iostream>
using namespace std;
int main() {
    int number;
    double reciprocal;
    cout << "Enter a non-zero number: ";
    cin >> number;
    if (number != 0) 
    {
        reciprocal = 1 / number;
        cout << "The reciprocal of " << number << " is: " << reciprocal << endl;
    } 
    else 
    {
        cout << "Division by zero is not allowed" << endl;
    }
    return 0;
}
