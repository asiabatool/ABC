#include <iostream>
using namespace std;
int main() {
    int num1, num2, num3, num4, num5,sum, avg, prod;
    cout << "Enter five number ";
    cin >> num1; 
    cin >> num2; 
    cin >> num3; 
    cin >> num4; 
    cin >> num5;
    sum = num1 + num2 + num3 + num4 + num5;
    avg = sum / 5;
     prod = num1 * num2 * num3 * num4 * num5;
    cout << "Sum: " << sum << endl;
    cout << "Average: " << avg << endl;
    cout << "Product: " << prod << endl;

    return 0;
}
