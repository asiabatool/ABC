#include <iostream>
using namespace std;
int main() {
    int a, b, c;

    cout << "Enter three numbers (a, b, c): ";
    cin >> a >> b >> c;

    int wholeSquare = a * a + b * b + c * c + 2 * (a * b + b * c + c * a);

    cout << "The whole square of (" << a << ", " << b << ", " << c << ") is: " << wholeSquare << endl;

    return 0;
}
