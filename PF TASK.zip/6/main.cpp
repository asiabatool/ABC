#include <iostream>
using namespace std;

int main() {
    int Num;
    cout << "Enter any number: ";
    cin >> Num;
    double result = ((Num * 2 + 10) / 2) - Num;
    if (result == 5) {
        std::cout << " The result is 5." << endl;
    } else {
        cout << " The result is not 5." << endl;
    }
    return 0;
}
