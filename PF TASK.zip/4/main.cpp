#include <iostream>
using namespace std;

int main() {
    float sub1, sub2, sub3, sub4, sub5;
    float total , percentage ;
    cout << "Enter the marks of Calculus out of 100:"<<endl;
    cin >> sub1;
    cout << "Enter the marks of Programming out of 100:"<<endl;
    cin >> sub2;
    cout << "Enter the marks of E and M out of 100:"<<endl;
    cin >> sub3;
    cout << "Enter the marks of fundamentals of CS out of 100:"<<endl;
    cin >> sub4;
    cout << "Enter the marks of Islamiat out of 100:"<<endl;
    cin >> sub5;
    total = sub1 + sub2 + sub3 + sub4 + sub5;
    percentage = (total / 500.0) * 100;
    cout << "\nThe Total marks   = " << total << "/500"<<endl;
    cout << "The Percentage    = " << percentage << "%"<<endl;
    return 0;
}
