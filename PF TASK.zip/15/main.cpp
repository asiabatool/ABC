#include <iostream>
using namespace std;

int main() 
{
    const double INCHES_TO_FEET = 1.0 / 12.0; 

    int inches;

    cout << "Enter the number of inches: ";
    cin >> inches;

    if (inches >= 0) {
        int feet = static_cast<int>(inches * INCHES_TO_FEET); 
        int remainingInches = inches % 12; 

        cout << inches << " inches is equivalent to " << feet << " feet and " << remainingInches << " inches." << endl;
    } 
    else 
    {
        cout << "Invalid input. Please enter a non-negative number of inches." << endl;
    }

    return 0;
}
