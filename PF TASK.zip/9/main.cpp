#include <iostream>
using namespace std;
int main() {
    int a, b;
    cout << "Enter two numbers (a and b): ";
    cin >> a >> b;
    int result = a * a + 2 * a * b + b * b;
    cout << "Result (x = a^2 + 2ab + b^2): " << result << endl;
    return 0;
}
