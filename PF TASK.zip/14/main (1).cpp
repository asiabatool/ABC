#include <stdio.h>

int main() {
    char input;
    
    printf("Enter a character from '0' to '9': ");
    scanf(" %c", &input); 
    
    if (input >= '0' && input <= '9') {
        int decimal = input - '0';
        printf("Corresponding decimal: %d\n", decimal);
    } else {
        printf("Invalid input. Please enter a character from '0' to '9'.\n");
    }

    return 0;
}
