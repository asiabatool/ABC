#include <iostream>
using namespace std;

int main() {
    int firstNumber, secondNumber,result;
    cout << "Enter the first single-digit number: ";
    cin >> firstNumber;

    cout << "Enter the second single-digit number: ";
    cin >> secondNumber;
    result = ((((firstNumber * 2 + 5) * 5 + secondNumber) - 4) - 21);
    if (result >= 0 && result <= 9) 
    {
        cout << "The trick worked! The result is: " << result << endl;
    } 
    else 
    {
        cout << "The result is not a single-digit number." << endl;
    }

    return 0;
}
