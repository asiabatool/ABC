#include <iostream>
using namespace std;

int main() 
{
    int num ,result ;
    cout << "Enter a number: ";
    cin >> num;
    result = ((num * 2 + 6) / 2) - num;
    if (result == 3) 
    {
        cout << "The Answer is 3." << endl;
    } else 
    {
        cout << "The Answer is not 3." << endl;
    }
    
    return 0;
}
