#include <iostream>
using namespace std;

int main() {
    float value1, value2, value3;
    cout << "Enter three floating-point values: ";
    cin >> value1 >> value2 >> value3;
    int square1 = value1 * value1;
    int square2 = value2 * value2;
    int square3 = value3 * value3;
    int sumOfSquares = square1 + square2 + square3;
    std::cout << "The sum of the squares is: " << sumOfSquares << endl;

    return 0;
}
