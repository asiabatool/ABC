#include <iostream>
using namespace std;

int main() {
    int minutes;
    
    cout << "Enter the number of minutes: ";
    cin >> minutes;

    if (minutes >= 0) {
        int hours = minutes / 60;
        int remainingMinutes = minutes % 60;

        cout << minutes << " minutes is equivalent to " << hours << " hours and " << remainingMinutes << " minutes." << endl;
    } 
    else 
    {
        cout << "Invalid input. Please enter a non-negative number of minutes." << endl;
    }

    return 0;
}
