#include <iostream>
using namespace std;

int main() 
{

    char alphabet;

    cout << "Enter an alphabet: ";
    cin >> alphabet;

    int asciiValue = static_cast<int>(alphabet);

  
    cout << "ASCII value of '" << alphabet << "' is: " << asciiValue << endl;

    return 0;
}
