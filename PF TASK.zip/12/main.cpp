#include <iostream>
using namespace std;

int main() 
{
    char lowercase;
    
    cout << "Enter a lowercase alphabet (a-z): ";
    cin >> lowercase;
    
    if (lowercase >= 'a' && lowercase <= 'z') 
    {
        char uppercase = lowercase - 'a' + 'A';
            cout << "Uppercase equivalent: " << uppercase << std::endl;
    } 
    else 
    {
        cout << "Invalid input. Please enter a lowercase alphabet." << std::endl;
    }

    return 0;
}
